L = [8,0,97,105,21,303]
maior = 0
menor = 0
i = 0
x = 0
while i < len(L):
    if L[i] > maior:
        maior = L[i]
    i = i + 1
print(maior)

while i < len(L):
    if L[i] < menor:
        menor = L[i]
    i = i + 1
print(menor)

print(L[0] + L[1] + L[2] + L[3] + L[4] + L[5])

i = 0
while i < len(L):
    if L[i]%2 != 0:
        x = L[i]
        print(x)
    i =  i + 1

i = 0
while i < len(L):
    if L[i] > 18:
        print(L[i])
    i =  i + 1
