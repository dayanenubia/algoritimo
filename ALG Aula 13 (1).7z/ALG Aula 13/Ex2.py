L = list(range(0,151,3))
print(L)
