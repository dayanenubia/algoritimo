con = 0
aux = 0
media = 0
L = []
N = int(input("Qual o número de notas que você vai digitar? "))
while con < N:
    x = int(input("Digite a nota: "))
    L.append(x)
    aux = aux + x
    con = con + 1
media = (aux/N)
print(L)
print(media)


