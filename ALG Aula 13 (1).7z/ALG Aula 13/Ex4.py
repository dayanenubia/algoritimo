con = 0
L = []
N = int(input("Quantos números que você vai digitar? "))
while con < N:
    x = int(input("Digite o número: "))
    L.append(x)
    con = con + 1
    
