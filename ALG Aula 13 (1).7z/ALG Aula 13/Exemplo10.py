cavaleiros = ["guerra","fome","peste","morte"]
cavaleiros.index("peste")

