L = list(range(5,13))
print(L)
