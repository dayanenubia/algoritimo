CAVALEIROS = ["guerra","fome","peste","morte"]
i = 0
while i < len(CAVALEIROS):
    print(CAVALEIROS[i])
    i = i + 1
