cavaleiros = ["guerra", "fome", "peste", "morte"]
for x in cavaleiros:
    print(x)
