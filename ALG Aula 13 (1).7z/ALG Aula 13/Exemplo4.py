cavaleiros = ["guerra", "fome", "peste", "morte"]
"fome" in cavaleiros


