cavaleiros = ["guerra","fome","peste"]
cavaleiros.insert(1,"morte")
print(cavaleiros)
