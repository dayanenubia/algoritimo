cavaleiros = ["guerra", "fome", "peste", "morte"]
cavaleiros.append("guerrilheiros")
print(cavaleiros)
