cavaleiros = ["guerra","fome","peste","morte"]
del cavaleiros[2]
print(cavaleiros)
