cavaleiros = ["guerra","fome","peste","morte"]
len(cavaleiros)

