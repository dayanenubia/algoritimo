L1 = [1,2,3]
L2 = [4,5,6]
X = L1+L2
print(X)
